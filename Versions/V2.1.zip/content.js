const STYLE_ID = 'cfa-yt-focus-mode-style';

function applyFocusMode(enabled) {
    let styleEl = document.getElementById(STYLE_ID);

    if (enabled) {
        if (!styleEl) {
            styleEl = document.createElement('style');
            styleEl.id = STYLE_ID;

            styleEl.textContent = `
                /* --- 1. HIDE ALL DISTRACTIONS --- */
                #masthead-container, 
                #secondary, 
                ytd-comments, 
                #related, 
                ytd-watch-next-secondary-results-renderer,
                #items.ytd-watch-next-secondary-results-renderer,
                ytd-live-chat-frame,
                #owner, 
                #actions, 
                #actions-inner, 
                #top-row ytd-video-owner-renderer,
                #description,
                #bottom-row { 
                    display: none !important; 
                }

                /* --- 2. GLOBAL BACKGROUND --- */
                html, body, ytd-app {
                    background-color: #020617 !important;
                    --ytd-masthead-height: 0px !important; 
                    overflow: hidden !important; /* No scrolling */
                    height: 100vh !important;
                    width: 100vw !important;
                    margin: 0 !important;
                    padding: 0 !important;
                }

                ytd-page-manager {
                    margin-top: 0 !important;
                    height: 100vh !important;
                    overflow: hidden !important;
                }

                /* --- 3. FORCE PROPORTIONAL VIDEO SIZE --- */
                ytd-watch-flexy {
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                    height: 100% !important;
                    width: 100% !important;
                    background: #020617 !important;
                }

                ytd-watch-flexy[flexy] #columns.ytd-watch-flexy,
                ytd-watch-flexy[flexy] #primary.ytd-watch-flexy,
                #primary-inner {
                    margin: 0 auto !important;
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    height: auto !important;
                    padding: 0 !important;
                }

                ytd-watch-flexy[flexy] #primary.ytd-watch-flexy {
                    padding: 0 !important;
                }

                /* Lock height and force a strict 16:9 aspect ratio */
                #player-container-outer, 
                #player-container-inner, 
                #player-container, 
                #ytd-player,
                .html5-video-player {
                    width: 100vw !important;
                    max-width: calc((100vh - 100px) * 16 / 9) !important;
                    height: auto !important;
                    max-height: calc(100vh - 100px) !important;
                    aspect-ratio: 16 / 9 !important;
                    margin: 0 auto !important;
                    border-radius: 0 !important; /* Remove curvature from video edge for fully immersive scale */
                    overflow: visible !important; 
                }

                .html5-video-container, 
                .html5-video-container video {
                    width: 100% !important;
                    height: 100% !important;
                    border-radius: 0 !important;
                }

                /* --- 4. THE GLOW EFFECT --- */
                #ytd-player {
                    box-shadow: 
                        0 0 60px 10px rgba(56, 189, 248, 0.15),
                        0 0 150px 40px rgba(15, 23, 42, 0.50),
                        0 0 300px 100px rgba(11, 40, 42, 0.40) !important;
                    z-index: 10;
                }

                /* --- 5. CLEAN UP BELOW THE VIDEO (JUST TITLE NOW) --- */
                #below {
                    width: 100% !important;
                    margin-top: 15px !important;
                    display: flex !important;
                    justify-content: center !important;
                    flex-direction: column !important;
                    align-items: center !important;
                }

                #above-the-fold {
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                    width: 100% !important;
                }

                #title h1 {
                    font-size: clamp(0.8rem, 3.5vw, 1.4rem) !important;
                    color: #e2e8f0 !important; 
                    font-weight: 500 !important;
                    margin: 0 !important;
                    line-height: 1.3 !important;
                    text-align: center !important;
                    width: 100% !important;
                    padding: 0 15px !important;
                    box-sizing: border-box !important;
                    display: -webkit-box !important;
                    -webkit-line-clamp: 2 !important;
                    -webkit-box-orient: vertical !important;
                    overflow: hidden !important;
                }
            `;
            document.head.appendChild(styleEl);
        }
    } else {
        if (styleEl) {
            styleEl.remove();
        }
    }
}

// Check initial state
chrome.storage.local.get(['youtubeFocusMode'], (result) => {
    if (result.youtubeFocusMode) {
        applyFocusMode(true);
    }
});

// Listen for changes from the popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.youtubeFocusMode) {
        applyFocusMode(changes.youtubeFocusMode.newValue);
    }
});